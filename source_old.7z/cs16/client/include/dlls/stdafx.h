#ifndef stdafx_h__
#define stdafx_h__

#include "extdll.h"
#include "util.h"

#endif // stdafx_h__