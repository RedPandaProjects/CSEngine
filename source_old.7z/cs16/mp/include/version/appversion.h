#ifndef __APPVERSION_H__
#define __APPVERSION_H__

// 
// This file is generated automatically.
// Don't edit it.
// 

// Version defines
#define APP_VERSION "5.7.0.0-dev"

#define APP_COMMIT_DATE "Dec 22 2018"
#define APP_COMMIT_TIME "22:29:28"

#define APP_COMMIT_SHA ""
#define APP_COMMIT_URL "/commits/"

#endif //__APPVERSION_H__

