using BearBuildTool.Projects;
using System.IO;
using System;
public class cs16_client :Project
{
	public cs16_client(string ProjectPath)
	{
		Include.Public.Add(Path.Combine(ProjectPath,"include","common"));
		Include.Public.Add(Path.Combine(ProjectPath,"include","engine"));
		Include.Public.Add(Path.Combine(ProjectPath,"include","game_shared"));
		Include.Public.Add(Path.Combine(ProjectPath,"include","pm_shared"));
		Include.Public.Add(Path.Combine(ProjectPath,"include","hud"));
		Include.Public.Add(Path.Combine(ProjectPath,"include","studio"));
		Include.Public.Add(Path.Combine(ProjectPath,"include","dlls"));
		Include.Public.Add(Path.Combine(ProjectPath,"include"));
			
		LibrariesStatic.Public.Add("wsock32.lib");
		LibrariesStatic.Public.Add("winmm.lib");
		
		AddSourceFiles(Path.Combine(ProjectPath,"source"),true);
		
		Defines.Public.Add("CLIENT_DLL");
		Defines.Public.Add("CLIENT_WEAPONS");
		Defines.Public.Add("HL_DLL");
		
    }
} 