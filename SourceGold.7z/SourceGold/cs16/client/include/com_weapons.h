//========= Copyright � 1996-2002, Valve LLC, All rights reserved. ============
//
// Purpose: 
//
// $NoKeywords: $
//=============================================================================
#pragma once
// com_weapons.h
// Shared weapons common function prototypes
#if !defined( COM_WEAPONSH )
#define COM_WEAPONSH


#include "hud_iface.h"

#define PLAYER_CAN_SHOOT (1 << 0)
#define PLAYER_FREEZE_TIME_OVER ( 1 << 1 )
#define PLAYER_IN_BOMB_ZONE (1 << 2)
#define PLAYER_HOLDING_SHIELD (1 << 3)

#define CROSSHAIR_
#define ACCURACY_AIR (1 << 0) // accuracy depends on FL_ONGROUND
#define ACCURACY_SPEED (1 << 1)
#define ACCURACY_DUCK (1 << 2) // more accurate when ducking
#define ACCURACY_MULTIPLY_BY_14 (1 << 3) // accuracy multiply to 1.4
#define ACCURACY_MULTIPLY_BY_14_2 (1 << 4) // accuracy multiply to 1.4

#ifndef WPNSTATE_USP_SILENCED
#define WPNSTATE_USP_SILENCED (1<<0)
#define WPNSTATE_GLOCK18_BURST_MODE (1<<1)
#define WPNSTATE_M4A1_SILENCED (1<<2)
#define WPNSTATE_ELITE_LEFT (1<<3)
#define WPNSTATE_FAMAS_BURST_MODE (1<<4)
#define WPNSTATE_SHIELD_DRAWN (1<<5)
#endif


extern "C"
{
	void _DLLEXPORT HUD_PostRunCmd( struct local_state_s *from, struct local_state_s *to, struct usercmd_s *cmd, int runfuncs, double time, unsigned int random_seed );
}

void			COM_Log( char *pszFile, char *fmt, ...);
int				CL_IsDead( void );

float			UTIL_SharedRandomFloat( unsigned int seed, float low, float high );
int				UTIL_SharedRandomLong( unsigned int seed, int low, int high );

int				HUD_GetWeaponAnim( void );
void			HUD_SendWeaponAnim( int iAnim, int body, int force );
void			HUD_PlaySound( char *sound, float volume );
void			HUD_PlaybackEvent( int flags, const struct edict_s *pInvoker, unsigned short eventindex, float delay, float *origin, float *angles, float fparam1, float fparam2, int iparam1, int iparam2, int bparam1, int bparam2 );
void			HUD_SetMaxSpeed( const struct edict_s *ed, float speed );
int				stub_PrecacheModel( char* s );
int				stub_PrecacheSound( char* s );
unsigned short	stub_PrecacheEvent( int type, const char *s );
const char		*stub_NameForFunction	( unsigned int function );
void			stub_SetModel			( struct edict_s *e, const char *m );
int				GetWeaponAccuracyFlags( int weaponid );

extern cvar_t *cl_lw;

extern int g_runfuncs;
extern vec3_t v_angles;
extern float g_lastFOV;
extern int g_iWeaponFlags;
extern bool g_bInBombZone;
extern int g_iFreezeTimeOver;
extern bool g_bHoldingShield;
extern int g_iPlayerFlags;
extern vec3_t g_vPlayerVelocity;
extern float g_flPlayerSpeed;
extern struct local_state_s *g_curstate;
extern struct local_state_s *g_finalstate;
extern int g_iShotsFired;

#endif
