/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*
*	This product contains software technology licensed from Id
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc.
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
#ifndef PLANE_H
#define PLANE_H

class CPlane 
{
public:
	CPlane(void);

public:
	void InitializePlane(const Vector &vecNormal, const Vector &vecPoint);
	BOOL PointInFront(const Vector &vecPoint);

public:
	Vector m_vecNormal;
	float m_flDist;
	BOOL m_fInitialized;
};

#endif