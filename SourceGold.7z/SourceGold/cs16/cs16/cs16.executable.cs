using BearBuildTool.Projects;
using System.IO;
using System;
public class cs16 :Executable
{
	public cs16(string ProjectPath)
	{
		Console=false;
		AddSourceFiles(Path.Combine(ProjectPath,"source"),true);
		IncludeAutonomousProjects.Add("source_engine");
		IncludeAutonomousProjects.Add("cs16_mp");
		IncludeAutonomousProjects.Add("cs16_client");
        IncludeAutonomousProjects.Add("cs16_menu");
    }
	public override void StartBuild()
	{
		BearBuildTool.Config.Global.UNICODE=false;
		BearBuildTool.Config.Global.WithoutWarning=true;
	}
} 