
#ifdef VULKAN
#define LOCATION_0 [[vk::location(0)]]
#define LOCATION_1 [[vk::location(1)]]
#define LOCATION_2 [[vk::location(2)]]
#define LOCATION_3 [[vk::location(3)]]
#define LOCATION_4 [[vk::location(4)]]
#define LOCATION_5 [[vk::location(5)]]
#define LOCATION_6 [[vk::location(6)]]
#define LOCATION_7 [[vk::location(7)]]

#else
#define LOCATION_0 
#define LOCATION_1 
#define LOCATION_2 
#define LOCATION_3 
#define LOCATION_4 
#define LOCATION_5 
#define LOCATION_6 
#define LOCATION_7 
#endif


#ifdef VULKAN
#define BINDING_0  [[vk::binding(0)]]
#define BINDING_1  [[vk::binding(1)]]
#define BINDING_2  [[vk::binding(2)]]
#define BINDING_3  [[vk::binding(3)]]
#define BINDING_4  [[vk::binding(4)]]
#define BINDING_5  [[vk::binding(5)]]
#define BINDING_6  [[vk::binding(6)]]
#else
#define BINDING_0  
#define BINDING_1 
#define BINDING_2  
#define BINDING_3  
#define BINDING_4  
#define BINDING_5 
#define BINDING_6  
#endif

struct VS_UV_IN
{
	LOCATION_0 float2 position : POSITION;
	LOCATION_1 float4 color:COLOR;
	LOCATION_2 float2 uv : UV;
};

struct PS_DEFUALT_IN
{
			   float4 position : SV_POSITION;
	LOCATION_0 float2 uv : UV;
	LOCATION_1 float4 color : COLOR;
};

